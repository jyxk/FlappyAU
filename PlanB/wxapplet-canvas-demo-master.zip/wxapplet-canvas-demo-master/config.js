module.exports = {
    host: 'https://jxy.me',  // 要请求的后端接口域名，必须和在公众平台上配置的一致

    bgMusic: {  // 背景音乐的地址和偏移量
        // url从baidu扒出来的，不保证啥时候失效
        url: 'http://yinyueshiting.baidu.com/data2/music/134368432/744166165600128.mp3?xcode=97ccaf99514434ca86c86b4d2d72cc37',
        offset: 84.9 // 单位是秒，还可以用小数。妈蛋手机上和电脑上偏移量还不一样，不知道是不是bug
    }
};
